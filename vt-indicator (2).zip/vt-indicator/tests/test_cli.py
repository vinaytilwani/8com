"""Public CLI behaviour: pipes, prompts, failures, and real file output."""

import errno
import io
import json
import subprocess
import sys
from unittest.mock import Mock

import pytest

from vt_indicator import cli
from vt_indicator.client import VirusTotalError

SHA256 = "ab" * 32
SECRET = "test-secret-that-must-not-be-disclosed"


class TerminalInput(io.StringIO):
    def isatty(self):
        return True


def invoke(arguments):
    """argparse may exit directly for usage/help; either API is observable."""
    try:
        return cli.main(arguments)
    except SystemExit as error:
        return error.code


@pytest.fixture
def fake_lookup(monkeypatch, report):
    monkeypatch.setenv("VT_API_KEY", SECRET)
    monkeypatch.setattr(sys, "stdin", io.StringIO())
    lookup = Mock(return_value=report)
    monkeypatch.setattr(cli, "fetch_report", lookup)
    return lookup


def test_stdout_is_pretty_json_array(fake_lookup, capsys):
    assert invoke([SHA256]) == 0
    out, err = capsys.readouterr()
    result = json.loads(out)
    assert len(result) == 1
    assert result[0]["score"] == 70
    assert out == json.dumps(result, indent=2) + "\n"
    assert err == ""
    fake_lookup.assert_called_once_with(SHA256, SECRET)


def test_file_output_leaves_stdout_empty(fake_lookup, tmp_path, capsys):
    target = tmp_path / "indicator.json"
    assert invoke([SHA256, "-o", str(target)]) == 0
    assert json.loads(target.read_text())[0]["id"] == SHA256
    assert target.read_text().endswith("\n")
    assert capsys.readouterr().out == ""


@pytest.mark.parametrize("arguments", [[], ["invalid"], ["a" * 63]])
def test_invalid_cli_input_makes_no_request(fake_lookup, capsys, arguments):
    assert invoke(arguments) == 2
    out, err = capsys.readouterr()
    assert out == ""
    assert err
    fake_lookup.assert_not_called()


def test_missing_key_noninteractive_is_usage_error(fake_lookup, monkeypatch, capsys):
    monkeypatch.delenv("VT_API_KEY")
    assert invoke([SHA256]) == 2
    out, err = capsys.readouterr()
    assert out == ""
    assert "VT_API_KEY" in err
    fake_lookup.assert_not_called()


def test_interactive_hash_prompt_keeps_stdout_parseable(fake_lookup, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", TerminalInput(SHA256 + "\n"))
    assert invoke([]) == 0
    out, err = capsys.readouterr()
    assert json.loads(out)[0]["id"] == SHA256
    assert err
    fake_lookup.assert_called_once_with(SHA256, SECRET)


def test_interactive_key_uses_getpass_and_is_not_serialized(fake_lookup, monkeypatch, capsys):
    monkeypatch.delenv("VT_API_KEY")
    monkeypatch.setattr(sys, "stdin", TerminalInput())
    hidden_prompt = Mock(return_value=SECRET)
    # Patch the standard library boundary, not the prompting implementation.
    monkeypatch.setattr(cli.getpass, "getpass", hidden_prompt)
    assert invoke([SHA256]) == 0
    out, err = capsys.readouterr()
    assert json.loads(out)[0]["id"] == SHA256
    assert SECRET not in out + err
    hidden_prompt.assert_called_once()


def test_eof_during_prompt_is_clean_usage_failure(fake_lookup, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", TerminalInput())
    assert invoke([]) == 2
    out, err = capsys.readouterr()
    assert out == ""
    assert err
    fake_lookup.assert_not_called()


def test_fetch_failure_preserves_existing_output(fake_lookup, tmp_path, capsys):
    target = tmp_path / "existing.json"
    target.write_text("previous valid output\n")
    fake_lookup.side_effect = VirusTotalError("VirusTotal report not found")
    assert invoke([SHA256, "-o", str(target)]) == 1
    assert target.read_text() == "previous valid output\n"
    out, err = capsys.readouterr()
    assert out == ""
    assert "not found" in err


def test_bad_report_preserves_existing_output(fake_lookup, tmp_path, capsys):
    target = tmp_path / "existing.json"
    target.write_text("previous valid output\n")
    fake_lookup.return_value = {"data": {"id": "cd" * 32}}
    assert invoke([SHA256, "-o", str(target)]) == 1
    assert target.read_text() == "previous valid output\n"
    out, err = capsys.readouterr()
    assert out == ""
    assert err


def test_unwritable_destination_is_reported(fake_lookup, tmp_path, capsys):
    assert invoke([SHA256, "-o", str(tmp_path / "missing" / "out.json")]) == 1
    out, err = capsys.readouterr()
    assert out == ""
    assert err


def test_unknown_score_is_success(fake_lookup, report, capsys):
    del report["data"]["attributes"]["last_analysis_stats"]
    assert invoke([SHA256]) == 0
    assert json.loads(capsys.readouterr().out)[0]["score"] is None


def test_help_needs_neither_key_nor_network(fake_lookup, monkeypatch, capsys):
    monkeypatch.delenv("VT_API_KEY")
    assert invoke(["--help"]) == 0
    assert "usage:" in capsys.readouterr().out.lower()
    fake_lookup.assert_not_called()


def test_module_entrypoint_help():
    result = subprocess.run(
        [sys.executable, "-m", "vt_indicator", "--help"],
        capture_output=True,
        text=True,
        check=False,
        timeout=10,
    )
    assert result.returncode == 0
    assert "usage:" in result.stdout.lower()
    assert result.stderr == ""


def test_replace_failure_preserves_old_file_and_cleans_temporary(
    fake_lookup, monkeypatch, tmp_path, capsys
):
    target = tmp_path / "existing.json"
    target.write_text("previous valid output\n")
    replace = Mock(side_effect=OSError("simulated filesystem failure"))
    monkeypatch.setattr(cli.os, "replace", replace)
    assert invoke([SHA256, "-o", str(target)]) == 1
    assert target.read_text() == "previous valid output\n"
    assert list(tmp_path.iterdir()) == [target]
    assert capsys.readouterr().err
    replace.assert_called_once()


def test_long_valid_output_filename_is_supported(fake_lookup, tmp_path, capsys):
    target = tmp_path / ("x" * 250)
    try:
        target.write_text("previous output\n")
    except OSError as error:
        if error.errno == errno.ENAMETOOLONG or getattr(error, "winerror", None) == 206:
            pytest.skip("This filesystem does not support the long destination name")
        raise

    assert invoke([SHA256, "-o", str(target)]) == 0
    assert json.loads(target.read_text())[0]["id"] == SHA256
    assert list(tmp_path.iterdir()) == [target]
    assert capsys.readouterr().err == ""


def test_key_prompt_refuses_echoing_fallback(fake_lookup, monkeypatch, capsys):
    monkeypatch.delenv("VT_API_KEY")
    monkeypatch.setattr(sys, "stdin", TerminalInput())
    monkeypatch.setattr(
        cli.getpass, "getpass", Mock(side_effect=cli.getpass.GetPassWarning("No hidden terminal"))
    )
    assert invoke([SHA256]) == 2
    out, err = capsys.readouterr()
    assert out == ""
    assert err
    fake_lookup.assert_not_called()


def test_console_entrypoint_help():
    from pathlib import Path

    executable = Path(sys.executable).parent / "vt-indicator"
    result = subprocess.run(
        [str(executable), "--help"], capture_output=True, text=True, check=False, timeout=10
    )
    assert result.returncode == 0
    assert "usage:" in result.stdout.lower()
    assert result.stderr == ""


def test_subprocess_noninteractive_missing_key_has_clean_failure():
    import os

    environment = {key: value for key, value in os.environ.items() if key != "VT_API_KEY"}
    result = subprocess.run(
        [sys.executable, "-m", "vt_indicator", SHA256],
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        env=environment,
        check=False,
        timeout=10,
    )
    assert result.returncode == 2
    assert result.stdout == ""
    assert "VT_API_KEY" in result.stderr
    assert "Traceback" not in result.stderr


def test_closed_downstream_pipe_exits_cleanly(report):
    import os

    # A small JSON result fits in Python's stdout buffer. Closing the consumer
    # exercises failure during flushing, not merely failure during a large write.
    script = (
        "from vt_indicator import cli; "
        f"cli.fetch_report = lambda *args: {report!r}; "
        f"raise SystemExit(cli.main([{SHA256!r}]))"
    )
    process = subprocess.Popen(
        [sys.executable, "-c", script],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env={**os.environ, "VT_API_KEY": SECRET},
    )
    assert process.stdout is not None
    assert process.stderr is not None
    process.stdout.close()
    process.stdout = None
    try:
        _, error = process.communicate(timeout=10)
    finally:
        if process.poll() is None:
            process.kill()
            process.communicate(timeout=10)
    assert process.returncode == 1
    assert error == b""
