"""HTTP boundary tests use fake responses, never VirusTotal requests."""

from unittest.mock import Mock

import pytest
import requests

from vt_indicator.client import VirusTotalError, fetch_report

SHA256 = "ab" * 32
SECRET = "test-secret-that-must-not-be-disclosed"


def stub_get(monkeypatch, *, status=200, payload=None, error=None):
    response = Mock(spec=requests.Response)
    response.status_code = status
    response.text = SECRET
    response.json.return_value = payload
    response.json.side_effect = error
    get = Mock(return_value=response)
    monkeypatch.setattr(requests, "get", get)
    return get


def test_request_contract(monkeypatch, report):
    get = stub_get(monkeypatch, payload=report)
    assert fetch_report(SHA256, SECRET) == report
    get.assert_called_once_with(
        f"https://www.virustotal.com/api/v3/files/{SHA256}",
        headers={"x-apikey": SECRET},
        timeout=(5, 30),
        allow_redirects=False,
    )


@pytest.mark.parametrize("status", [301, 401, 403, 404, 429, 500, 503])
def test_http_errors_are_safe_and_not_retried(monkeypatch, status):
    get = stub_get(monkeypatch, status=status)
    with pytest.raises(VirusTotalError) as caught:
        fetch_report(SHA256, SECRET)
    assert SECRET not in str(caught.value)
    get.assert_called_once()


@pytest.mark.parametrize("error", [requests.Timeout, requests.ConnectionError])
def test_network_failures_are_safe(monkeypatch, error):
    get = Mock(side_effect=error(SECRET))
    monkeypatch.setattr(requests, "get", get)
    with pytest.raises(VirusTotalError) as caught:
        fetch_report(SHA256, SECRET)
    assert SECRET not in str(caught.value)
    get.assert_called_once()


@pytest.mark.parametrize("payload", [None, [], "not an object", 3])
def test_nonobject_json_is_rejected(monkeypatch, payload):
    stub_get(monkeypatch, payload=payload)
    with pytest.raises(VirusTotalError):
        fetch_report(SHA256, SECRET)


def test_invalid_json_is_rejected_without_exposing_body(monkeypatch):
    stub_get(monkeypatch, error=requests.exceptions.JSONDecodeError(SECRET, "x", 0))
    with pytest.raises(VirusTotalError) as caught:
        fetch_report(SHA256, SECRET)
    assert SECRET not in str(caught.value)


def test_missing_key_never_requests(monkeypatch):
    get = Mock()
    monkeypatch.setattr(requests, "get", get)
    with pytest.raises(VirusTotalError):
        fetch_report(SHA256, "")
    get.assert_not_called()


def test_response_is_closed_after_success(monkeypatch, report):
    get = stub_get(monkeypatch, payload=report)
    fetch_report(SHA256, SECRET)
    get.return_value.close.assert_called_once_with()


@pytest.mark.parametrize("status", [404, 429, 503])
def test_response_is_closed_after_http_error(monkeypatch, status):
    get = stub_get(monkeypatch, status=status)
    with pytest.raises(VirusTotalError):
        fetch_report(SHA256, SECRET)
    get.return_value.close.assert_called_once_with()


def test_response_is_closed_after_json_error(monkeypatch):
    get = stub_get(monkeypatch, error=ValueError("invalid JSON"))
    with pytest.raises(VirusTotalError):
        fetch_report(SHA256, SECRET)
    get.return_value.close.assert_called_once_with()


def test_invalid_hash_never_requests(monkeypatch):
    get = Mock()
    monkeypatch.setattr(requests, "get", get)
    with pytest.raises(ValueError):
        fetch_report("bad-hash", SECRET)
    get.assert_not_called()


@pytest.mark.parametrize(
    "api_key",
    [
        "test-\u20ac-key",
        "test-\u00e9-key",
        "test key",
        "test\tkey",
        "test\nkey",
        "test\x00key",
        "test\x7fkey",
    ],
)
def test_malformed_api_key_is_rejected_before_http(monkeypatch, api_key):
    get = Mock()
    monkeypatch.setattr(requests, "get", get)
    with pytest.raises(VirusTotalError) as caught:
        fetch_report(SHA256, api_key)
    assert api_key not in str(caught.value)
    get.assert_not_called()


def test_api_key_surrounding_whitespace_is_normalized(monkeypatch, report):
    get = stub_get(monkeypatch, payload=report)
    assert fetch_report(SHA256, f" \t{SECRET}\n") == report
    assert get.call_args.kwargs["headers"] == {"x-apikey": SECRET}


def test_bad_request_includes_provider_diagnostic(monkeypatch):
    get = stub_get(
        monkeypatch,
        status=400,
        payload={"error": {"code": "InvalidArgumentError", "message": "Invalid file identifier"}},
    )
    with pytest.raises(VirusTotalError) as caught:
        fetch_report(SHA256, SECRET)
    assert "HTTP 400" in str(caught.value)
    assert "InvalidArgumentError" in str(caught.value)
    assert "Invalid file identifier" in str(caught.value)
    get.assert_called_once()
    get.return_value.close.assert_called_once()


def test_error_diagnostic_redacts_key_before_truncating_and_escapes_controls(monkeypatch):
    stub_get(
        monkeypatch,
        status=400,
        payload={
            "error": {
                "code": SECRET,
                "message": "\x1b[31mBad\n" + SECRET.upper() + " " + "x" * 800 + SECRET,
            },
            "debug": SECRET,
        },
    )
    with pytest.raises(VirusTotalError) as caught:
        fetch_report(SHA256, SECRET)
    message = str(caught.value)
    assert SECRET.lower() not in message.lower()
    assert "[REDACTED]" in message
    assert "\x1b" not in message
    assert "\n" not in message
    assert len(message) < 800


@pytest.mark.parametrize(
    "payload",
    [None, [], {}, {"error": None}, {"error": "bad"}, {"error": {"code": 42, "message": []}}],
)
def test_unstructured_error_falls_back_to_http_status(monkeypatch, payload):
    stub_get(monkeypatch, status=400, payload=payload)
    with pytest.raises(VirusTotalError) as caught:
        fetch_report(SHA256, SECRET)
    assert "HTTP 400" in str(caught.value)
    assert "No structured" in str(caught.value)
    assert SECRET not in str(caught.value)


def test_html_error_body_is_not_printed(monkeypatch):
    stub_get(monkeypatch, status=400, error=ValueError(SECRET))
    with pytest.raises(VirusTotalError) as caught:
        fetch_report(SHA256, SECRET)
    assert "HTTP 400" in str(caught.value)
    assert SECRET not in str(caught.value)
