"""Executable documentation and an actual Unix JSON pipeline."""

import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from vt_indicator import build_indicator

EXAMPLES = Path(__file__).resolve().parents[1] / "examples"


def test_documented_fixture_matches_hand_reviewed_output():
    report = json.loads((EXAMPLES / "vt_response.synthetic.json").read_text())
    expected = json.loads((EXAMPLES / "indicator.synthetic.json").read_text())
    assert [build_indicator(report, report["data"]["id"])] == expected


def test_offline_example_pipes_into_real_jq():
    jq = shutil.which("jq")
    if jq is None:
        pytest.skip("jq is optional; install it to verify the Unix pipeline")
    producer = subprocess.Popen(
        [sys.executable, str(EXAMPLES / "offline.py")],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    try:
        assert producer.stdout is not None
        consumer = subprocess.run(
            [jq, "-e", ".[0].score == 70"],
            stdin=producer.stdout,
            capture_output=True,
            text=True,
            check=False,
            timeout=10,
        )
        producer.stdout.close()
        producer.stdout = None
        _, error = producer.communicate(timeout=10)
    finally:
        if producer.poll() is None:
            producer.kill()
            producer.communicate(timeout=10)
    assert producer.returncode == 0, error
    assert consumer.returncode == 0, consumer.stderr
    assert consumer.stdout == "true\n"
