"""Synthetic, hand-reviewed VirusTotal responses; never live network fixtures."""

import pytest

SHA256 = "ab" * 32


@pytest.fixture
def report():
    return {
        "data": {
            "id": SHA256,
            "type": "file",
            "attributes": {
                "first_submission_date": 0,
                "last_analysis_date": 1_700_000_000,
                "meaningful_name": "example.exe",
                "last_analysis_stats": {
                    "malicious": 6,
                    "suspicious": 2,
                    "harmless": 2,
                    "undetected": 60,
                    "timeout": 1,
                },
                "reputation": -12,
                "total_votes": {"harmless": 2, "malicious": 7},
            },
        }
    }
