"""Contract examples and invariants written independently of implementation."""

from copy import deepcopy

import pytest
from hypothesis import given
from hypothesis import strategies as st

from vt_indicator.core import (
    ReportError,
    build_indicator,
    calculate_score,
    validate_sha256,
)

SHA256 = "ab" * 32
COUNTS = st.integers(min_value=0, max_value=1_000_000)


@pytest.mark.parametrize("value", [SHA256, SHA256.upper(), "0" * 64, "f" * 64])
def test_valid_sha256_is_normalized(value):
    assert validate_sha256(value) == value.lower()


@pytest.mark.parametrize(
    "value",
    ["", "a" * 63, "a" * 65, "g" * 64, " " + SHA256, SHA256 + "\n", "\uff41" * 64],
)
def test_invalid_sha256_is_rejected(value):
    with pytest.raises(ValueError):
        validate_sha256(value)


@pytest.mark.parametrize(
    ("malicious", "suspicious", "harmless", "expected"),
    [
        (6, 2, 2, 70),
        (0, 0, 10, 0),
        (1, 0, 0, 100),
        (0, 1, 0, 50),
        (0, 0, 0, None),
        (1, 0, 2, 33),
        (1, 0, 7, 12),
        (3, 0, 5, 38),
        (0, 1, 3, 12),
    ],
)
def test_score_examples(malicious, suspicious, harmless, expected):
    assert calculate_score(malicious, suspicious, harmless) == expected


@pytest.mark.parametrize("invalid", [-1, 1.0, "1", True, None])
@pytest.mark.parametrize("position", [0, 1, 2])
def test_score_rejects_invalid_counts(invalid, position):
    counts = [1, 1, 1]
    counts[position] = invalid
    with pytest.raises(ValueError):
        calculate_score(*counts)


@given(COUNTS, COUNTS, COUNTS)
def test_score_is_bounded_or_absent(malicious, suspicious, harmless):
    score = calculate_score(malicious, suspicious, harmless)
    if malicious + suspicious + harmless == 0:
        assert score is None
    else:
        assert type(score) is int
        assert 0 <= score <= 100


@given(COUNTS, COUNTS, COUNTS, st.integers(min_value=1, max_value=100))
def test_scaling_all_counts_preserves_score(malicious, suspicious, harmless, factor):
    assert calculate_score(malicious, suspicious, harmless) == calculate_score(
        malicious * factor, suspicious * factor, harmless * factor
    )


@given(COUNTS, COUNTS, st.integers(min_value=1, max_value=1_000_000), COUNTS)
def test_more_malicious_cannot_lower_score(malicious, suspicious, harmless, extra):
    assert calculate_score(malicious + extra, suspicious, harmless) >= calculate_score(
        malicious, suspicious, harmless
    )


@given(st.integers(min_value=1, max_value=1_000_000), COUNTS, COUNTS, COUNTS)
def test_more_harmless_cannot_raise_score(malicious, suspicious, harmless, extra):
    assert calculate_score(malicious, suspicious, harmless + extra) <= calculate_score(
        malicious, suspicious, harmless
    )


@given(st.integers(min_value=1, max_value=1_000_000))
def test_suspicious_only_always_means_fifty(suspicious):
    assert calculate_score(0, suspicious, 0) == 50


def test_adding_suspicious_can_lower_a_high_score():
    assert calculate_score(1, 0, 0) == 100
    assert calculate_score(1, 1, 0) == 75


def test_complete_mapping_and_no_input_mutation(report):
    original = deepcopy(report)
    assert build_indicator(report, SHA256) == {
        "id": SHA256,
        "type": "file-hash",
        "first_seen": "1970-01-01T00:00:00Z",
        "last_analysis_date": "2023-11-14T22:13:20Z",
        "score": 70,
        "score_method": "weighted_explicit_verdict_ratio_v1",
        "malicious_engines": 6,
        "suspicious_engines": 2,
        "harmless_engines": 2,
        "opinionated_engines": 10,
        "undetected_engines": 60,
        "sources": ["VirusTotal"],
        "file_name": "example.exe",
        "community": {"reputation": -12, "votes": {"harmless": 2, "malicious": 7}},
        "raw": {"last_analysis_stats": original["data"]["attributes"]["last_analysis_stats"]},
    }
    assert report == original


def test_absent_optional_data_is_unknown(report):
    report["data"]["attributes"] = {}
    result = build_indicator(report, SHA256)
    for key in (
        "first_seen",
        "last_analysis_date",
        "score",
        "file_name",
        "malicious_engines",
        "suspicious_engines",
        "harmless_engines",
        "opinionated_engines",
        "undetected_engines",
    ):
        assert result[key] is None
    assert result["community"] == {"reputation": None, "votes": None}
    assert result["raw"]["last_analysis_stats"] is None


def test_zero_is_distinct_from_absence(report):
    attrs = report["data"]["attributes"]
    attrs["last_analysis_stats"] = {"malicious": 0, "suspicious": 0, "harmless": 1}
    attrs["reputation"] = 0
    attrs["total_votes"] = {"harmless": 0, "malicious": 0}
    result = build_indicator(report, SHA256)
    assert result["score"] == 0
    assert result["community"]["reputation"] == 0
    assert result["undetected_engines"] is None


@given(undetected=COUNTS, failures=COUNTS)
def test_excluded_categories_do_not_change_score(undetected, failures):
    report = {
        "data": {
            "id": SHA256,
            "type": "file",
            "attributes": {
                "last_analysis_stats": {
                    "malicious": 6,
                    "suspicious": 2,
                    "harmless": 2,
                    "undetected": undetected,
                    "failure": failures,
                }
            },
        }
    }
    assert build_indicator(report, SHA256)["score"] == 70


@pytest.mark.parametrize("bad", [None, [], {}, {"data": []}, {"data": {"attributes": {}}}])
def test_bad_envelope_is_rejected(bad):
    with pytest.raises(ReportError):
        build_indicator(bad, SHA256)


@pytest.mark.parametrize(("key", "value"), [("id", "cd" * 32), ("type", "url")])
def test_wrong_report_identity_is_rejected(report, key, value):
    report["data"][key] = value
    with pytest.raises(ReportError):
        build_indicator(report, SHA256)


@pytest.mark.parametrize(
    ("field", "value"),
    [
        ("last_analysis_stats", None),
        ("last_analysis_stats", {"malicious": 1, "suspicious": 0}),
        ("last_analysis_stats", {"malicious": -1, "suspicious": 0, "harmless": 1}),
        ("last_analysis_stats", {"malicious": True, "suspicious": 0, "harmless": 1}),
        ("first_submission_date", "0"),
        ("first_submission_date", True),
        ("last_analysis_date", 10**30),
        ("meaningful_name", 42),
        ("reputation", False),
        ("reputation", "-12"),
        ("total_votes", {"harmless": 1}),
        ("total_votes", {"harmless": 1, "malicious": -1}),
    ],
)
def test_malformed_consumed_fields_are_rejected(report, field, value):
    report["data"]["attributes"][field] = value
    with pytest.raises(ReportError):
        build_indicator(report, SHA256)


def test_unrelated_attributes_are_ignored(report):
    expected = build_indicator(report, SHA256)
    report["data"]["attributes"]["future_api_extension"] = {"anything": [None, "ok"]}
    assert build_indicator(report, SHA256) == expected


@given(count=COUNTS)
def test_future_engine_category_does_not_change_known_score(count):
    stats = {"malicious": 6, "suspicious": 2, "harmless": 2, "future_category": count}
    report = {"data": {"id": SHA256, "type": "file", "attributes": {"last_analysis_stats": stats}}}
    result = build_indicator(report, SHA256)
    assert result["score"] == 70
    assert result["raw"]["last_analysis_stats"]["future_category"] == count


@given(
    st.tuples(COUNTS, COUNTS, COUNTS).filter(lambda counts: sum(counts) > 0),
    st.integers(min_value=1, max_value=1_000_000),
)
def test_adding_suspicious_moves_score_toward_fifty_without_crossing(counts, extra):
    malicious, suspicious, harmless = counts
    original = calculate_score(malicious, suspicious, harmless)
    updated = calculate_score(malicious, suspicious + extra, harmless)
    assert min(original, 50) <= updated <= max(original, 50)
    assert abs(updated - 50) <= abs(original - 50)
