# Local verification

Verified on 2026-11-11 with CPython 3.12.14 on Linux.
Dependencies were installed in an isolated project environment with `uv sync`;
the resolved versions are recorded in `uv.lock`.

| Check | Observed result |
|---|---|
| `uv run ruff check .` | Passed. |
| `uv run ruff format --check .` | Passed. |
| `uv run mypy` | Passed in strict mode; 6 source files. |
| `uv run pytest --cov --cov-report=term-missing` | 129 passed after review and diagnostic fixes. |
| Combined statement/branch coverage | 96%; core and HTTP client each 100%. |
| `uv run python examples/offline.py` piped into `jq` | Parsed array; score was 70. |
| `uv build` | Source distribution and Python wheel built successfully. |
| Install wheel in a separate virtual environment | Passed. |
| Installed console command `--help`, outside source checkout | Passed. |
| Import installed package and transform synthetic report | Passed; score was 70. |
| Wheel type marker | `vt_indicator/py.typed` present. |

Tests were authored by a separate agent from a written interface contract,
before inspecting the implementation. They include example-based tests,
Hypothesis properties, and subprocess checks. A real closed-pipe regression was
observed failing (exit 120 and interpreter-shutdown error), then verified passing
after flushing JSON inside the CLI's error-handling boundary.

## Independent review follow-up

Three additional agents reviewed production code, CLI/tests, and Windows/docs.
Concrete findings were reproduced and addressed:

| Finding | Correction and evidence |
|---|---|
| Non-ASCII API key could raise an uncaught header-encoding exception; whitespace could produce a misleading network error. | Reject non-visible-ASCII/internal-space keys before HTTP. Seven rejection regressions failed before the fix and now pass; surrounding whitespace normalization also passes. |
| Client missing-key message assumed the CLI environment variable. | Library message now requests an explicit nonempty key. CLI retains environment-specific guidance. |
| A valid long destination filename produced an oversized temporary filename. | Use a short constant temporary-file prefix. Regression failed before the fix and now passes. |
| Subprocess tests could block before reaching their timeout. | Use bounded `communicate`/`run` calls and kill/reap cleanup. |
| Mocked getpass test name implied actual echo suppression was tested. | Rename to describe delegation/non-disclosure. Reviewer separately checked a real Linux pseudo-terminal: echo off during key entry, restored afterward, no key in output, valid JSON stdout. |
| Offline instructions could imply a fresh dependency installation needed no network. | Explicitly separate initial setup from the offline example and use `--no-sync` there. |

Windows PowerShell instructions and a code explainer are included as `WINDOWS.md`
and `EXPLAINER.md`. CI now declares Ubuntu and Windows jobs; neither hosted job
has been executed here. The review did not establish any Windows runtime result.

## HTTP 400 diagnostic follow-up

The user reported a live HTTP 400 response on their machine. The previous client
discarded the provider's error details, so that status alone could not establish
the cause. The client now includes bounded `error.code` and `error.message`
strings, redacts the supplied key before truncation, and JSON-escapes terminal
control characters. It does not print raw bodies or headers. Non-JSON/malformed
error envelopes retain the HTTP status with an explicit fallback explanation.
Nine additional tests cover useful diagnostics, credential redaction, control
escaping, malformed envelopes, and HTML responses. The user's underlying HTTP
400 cause remains unknown until their diagnostic response is available.

Coverage does not include child-process execution by default. Module entry
points and closed-pipe behaviour are exercised in subprocesses even though some
corresponding lines appear uncovered in the in-process coverage report. Coverage
is evidence of exercised paths, not a proof of correctness.

## Checks not performed

- No authenticated VirusTotal request: `VT_API_KEY` was not configured in the
  development environment. Use the real MalwareBazaar hash from the README for
  a live check with your own key; enter it into the hidden terminal prompt.
- The MalwareBazaar source page and its hash were verified, but no malware bytes
  were downloaded or executed.
- No hosted GitHub Actions execution; the workflow file is ready for a repository.
- No runtime verification on Windows or macOS. The implementation uses portable
  Python APIs; platform-specific terminal/filesystem behaviour remains unverified.

Reproduce the checks using the commands in the README. Do not interpret the
synthetic fixture as live VirusTotal evidence about the MalwareBazaar sample.
