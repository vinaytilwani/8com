# Windows and PowerShell walkthrough

The development copy is in a remote Linux workspace at
`/workspace/scratch/bf567db5bec7/vt-indicator`. That path is not on your Windows
computer. Download `vt-indicator.zip` first; the commands below assume it is in
your Downloads folder with that exact name.

## Install uv once

Check whether it is already installed:

```powershell
Get-Command uv -ErrorAction SilentlyContinue
```

If that prints nothing, install it using the command documented by Astral:

```powershell
winget install --id=astral-sh.uv -e
```

Then open a new PowerShell window so the updated PATH is visible. If WinGet is
unavailable, follow the Windows installer instructions at
https://docs.astral.sh/uv/getting-started/installation/.

## Extract and set up

Run this block once. It refuses to overwrite an existing project directory.
If the ZIP was downloaded elsewhere, change `$archivePath`.

```powershell
$ErrorActionPreference = 'Stop'
$archivePath = Join-Path $HOME 'Downloads\vt-indicator.zip'
$projectParent = Join-Path $HOME 'Projects'
$projectPath = Join-Path $projectParent 'vt-indicator'

if (Test-Path -LiteralPath $projectPath) {
    throw "Directory already exists: $projectPath. Choose another projectParent."
}

Expand-Archive -LiteralPath $archivePath -DestinationPath $projectParent
Set-Location -LiteralPath $projectPath

uv python install 3.12
if ($LASTEXITCODE -ne 0) { throw 'Python installation failed.' }
uv sync --locked
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
uv run --no-sync vt-indicator --help
if ($LASTEXITCODE -ne 0) { throw 'Command installation check failed.' }
```

Your project is now at `$HOME\Projects\vt-indicator`, usually
`C:\Users\YOUR_NAME\Projects\vt-indicator`. No administrator shell or virtual
environment activation is needed for the project commands. Initial installation
requires internet access. `uv` creates the project-local `.venv`; `uv run` selects it.

PowerShell's `$ErrorActionPreference` does not reliably turn unsuccessful native
commands into exceptions across versions, so the setup checks `$LASTEXITCODE`.

## Try it without an API key

```powershell
uv run --no-sync python .\examples\offline.py

$result = uv run --no-sync python .\examples\offline.py | Out-String | ConvertFrom-Json
$result | Select-Object id, score, opinionated_engines
```

The synthetic example must show score **70** and **10** opinionated engines.
It uses no network after installation. This is a transformation demonstration,
not a live result about the MalwareBazaar hash.

## Real lookup with a hidden key prompt

```powershell
$sha256 = '2ac22d4a395b8c0260d21b2ba81dd795ca072deb34be0bbe1072e1a66dc7c1b1'
uv run --no-sync vt-indicator $sha256 -o .\indicators.json
if ($LASTEXITCODE -ne 0) { throw 'Lookup failed; read the error above.' }

Get-Content -Raw .\indicators.json |
    ConvertFrom-Json |
    Select-Object id, score, malicious_engines, suspicious_engines, opinionated_engines
```

Enter your key when prompted; it is not displayed or saved by the program.
If `VT_API_KEY` already exists in the environment, the program uses it without
prompting. Run this in a regular interactive PowerShell terminal. A non-interactive
runner needs `VT_API_KEY` supplied through its environment/secret settings.

To enter both hash and key interactively:

```powershell
uv run --no-sync vt-indicator -o .\indicators.json
```

Use `-o` to write files. Windows PowerShell 5.1's `>` redirection uses UTF-16LE;
the program's own file writer controls encoding and replaces files atomically.
If lookup fails, a previous `indicators.json` remains untouched, so check the
exit status before reading that file as a new result.

## Inspect JSON with PowerShell or jq

PowerShell already includes JSON handling; jq is optional:

```powershell
$result = Get-Content -Raw .\indicators.json | ConvertFrom-Json
$result | Select-Object id, score, last_analysis_date
$result.community
```

If jq is installed:

```powershell
jq '.[0].score' .\indicators.json
uv run --no-sync python .\examples\offline.py | jq '.[0].score'
```

These examples use short jq expressions without embedded double quotes, avoiding
native-command quoting differences between Windows PowerShell 5.1 and PowerShell 7.

## Run the development checks

```powershell
uv run --no-sync ruff check .
uv run --no-sync ruff format --check .
uv run --no-sync mypy
uv run --no-sync pytest --cov --cov-report=term-missing
uv build
```

Read each command's result. A skipped jq test means jq was not found, not a product
failure. The commands and APIs were reviewed for Windows compatibility, but this
project's runtime checks were performed on Linux; no Windows execution is claimed.

Official references:

- uv installation: https://docs.astral.sh/uv/getting-started/installation/
- PowerShell JSON: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.utility/convertfrom-json
- PowerShell encoding: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_character_encoding?view=powershell-5.1
