"""Pure validation and transformation of VirusTotal file reports."""

import re
from datetime import UTC, datetime
from fractions import Fraction
from typing import Literal, TypedDict, cast

SCORE_METHOD = "weighted_explicit_verdict_ratio_v1"


class ReportError(ValueError):
    """The provider response cannot be interpreted without inventing data."""


class Votes(TypedDict):
    harmless: int
    malicious: int


class Community(TypedDict):
    reputation: int | None
    votes: Votes | None


class Evidence(TypedDict):
    last_analysis_stats: dict[str, int] | None


class Indicator(TypedDict):
    """Stable JSON-serializable result; null represents unavailable evidence."""

    id: str
    type: Literal["file-hash"]
    first_seen: str | None
    last_analysis_date: str | None
    score: int | None
    score_method: str
    malicious_engines: int | None
    suspicious_engines: int | None
    harmless_engines: int | None
    opinionated_engines: int | None
    undetected_engines: int | None
    sources: list[str]
    file_name: str | None
    community: Community
    raw: Evidence


def validate_sha256(value: str) -> str:
    """Return a lowercase SHA256, rejecting whitespace and non-ASCII hex."""
    if not isinstance(value, str) or re.fullmatch(r"[0-9a-fA-F]{64}", value) is None:
        raise ValueError("SHA256 must contain exactly 64 hexadecimal characters.")
    return value.lower()


def _integer(value: object, field: str, *, nonnegative: bool = True) -> int:
    # bool subclasses int in Python, but true is not a valid engine count.
    if isinstance(value, bool) or not isinstance(value, int):
        raise ReportError(f"{field} must be an integer.")
    if nonnegative and value < 0:
        raise ReportError(f"{field} must be nonnegative.")
    return value


def calculate_score(malicious: int, suspicious: int, harmless: int) -> int | None:
    """Compute round(100*(M + 0.5*S)/(M + S + H)), or None without verdicts.

    Exact rational arithmetic avoids float precision loss, including tie cases.
    Rounding uses ties-to-even. This is an evidence index, not a probability.
    """
    for name, count in (
        ("malicious", malicious),
        ("suspicious", suspicious),
        ("harmless", harmless),
    ):
        _integer(count, name)
    total = malicious + suspicious + harmless
    return round(Fraction(50 * (2 * malicious + suspicious), total)) if total else None


def _object(value: object, field: str) -> dict[str, object]:
    if not isinstance(value, dict) or any(not isinstance(key, str) for key in value):
        raise ReportError(f"{field} must be a JSON object.")
    return cast("dict[str, object]", value)


def _date(attributes: dict[str, object], field: str) -> str | None:
    if field not in attributes:
        return None
    timestamp = _integer(attributes[field], field)
    try:
        return (
            datetime.fromtimestamp(timestamp, tz=UTC)
            .isoformat(timespec="seconds")
            .replace("+00:00", "Z")
        )
    except (OverflowError, OSError, ValueError) as exc:
        raise ReportError(f"{field} is outside the supported timestamp range.") from exc


def _stats(attributes: dict[str, object]) -> dict[str, int] | None:
    if "last_analysis_stats" not in attributes:
        return None
    raw = _object(attributes["last_analysis_stats"], "last_analysis_stats")
    if not {"malicious", "suspicious", "harmless"}.issubset(raw):
        raise ReportError("last_analysis_stats requires malicious, suspicious and harmless counts.")
    return {name: _integer(value, "analysis count") for name, value in raw.items()}


def _community(attributes: dict[str, object]) -> Community:
    reputation = (
        _integer(attributes["reputation"], "reputation", nonnegative=False)
        if "reputation" in attributes
        else None
    )
    votes: Votes | None = None
    if "total_votes" in attributes:
        raw = _object(attributes["total_votes"], "total_votes")
        if not {"harmless", "malicious"}.issubset(raw):
            raise ReportError("total_votes requires harmless and malicious counts.")
        votes = {
            "harmless": _integer(raw["harmless"], "total_votes.harmless"),
            "malicious": _integer(raw["malicious"], "total_votes.malicious"),
        }
    return {"reputation": reputation, "votes": votes}


def build_indicator(report: object, expected_sha256: str) -> Indicator:
    """Validate consumed fields and build a fresh indicator without modifying input.

    Missing optional evidence becomes null; present but malformed evidence raises
    ReportError. Unrelated provider attributes are ignored for forward compatibility.
    """
    sha256 = validate_sha256(expected_sha256)
    data = _object(_object(report, "report").get("data"), "data")
    if data.get("type") != "file" or data.get("id") != sha256:
        raise ReportError("Report must describe the requested SHA256 file.")
    attributes = _object(data.get("attributes"), "attributes")
    stats = _stats(attributes)
    name = attributes.get("meaningful_name")
    if name is not None and not isinstance(name, str):
        raise ReportError("meaningful_name must be a string or null.")

    return {
        "id": sha256,
        "type": "file-hash",
        "first_seen": _date(attributes, "first_submission_date"),
        "last_analysis_date": _date(attributes, "last_analysis_date"),
        "score": (
            calculate_score(stats["malicious"], stats["suspicious"], stats["harmless"])
            if stats is not None
            else None
        ),
        "score_method": SCORE_METHOD,
        "malicious_engines": stats["malicious"] if stats is not None else None,
        "suspicious_engines": stats["suspicious"] if stats is not None else None,
        "harmless_engines": stats["harmless"] if stats is not None else None,
        "opinionated_engines": (
            stats["malicious"] + stats["suspicious"] + stats["harmless"]
            if stats is not None
            else None
        ),
        "undetected_engines": stats.get("undetected") if stats is not None else None,
        "sources": ["VirusTotal"],
        "file_name": name,
        "community": _community(attributes),
        "raw": {"last_analysis_stats": stats},
    }
