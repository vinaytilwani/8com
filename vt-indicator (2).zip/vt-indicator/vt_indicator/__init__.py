"""VirusTotal file-hash enrichment, usable without the command-line interface."""

from vt_indicator.client import VirusTotalError, fetch_report
from vt_indicator.core import (
    Indicator,
    ReportError,
    build_indicator,
    calculate_score,
    validate_sha256,
)

__all__ = [
    "Indicator",
    "ReportError",
    "VirusTotalError",
    "build_indicator",
    "calculate_score",
    "fetch_report",
    "validate_sha256",
]
