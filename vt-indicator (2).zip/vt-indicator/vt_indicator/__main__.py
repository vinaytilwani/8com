"""Support python -m vt_indicator."""

from vt_indicator.cli import main

raise SystemExit(main())
