"""Terminal adapter. Library callers should use the public package functions."""

import argparse
import getpass
import json
import os
import sys
import tempfile
import warnings
from collections.abc import Sequence
from pathlib import Path

from vt_indicator.client import VirusTotalError, fetch_report
from vt_indicator.core import Indicator, ReportError, build_indicator, validate_sha256


def write_json_atomic(path: Path, indicators: Sequence[Indicator]) -> None:
    """Replace a file only after a complete UTF-8 JSON document is ready.

    A temporary file in the same directory permits an atomic replacement on the
    same filesystem. This protects readers from partial JSON, not from power loss.
    """
    content = json.dumps(list(indicators), indent=2, ensure_ascii=True, allow_nan=False) + "\n"
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", dir=path.parent, prefix=".vt-indicator-", delete=False
        ) as stream:
            temporary = Path(stream.name)
            stream.write(content)
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vt-indicator",
        description="Look up a SHA256 in VirusTotal and emit a JSON indicator array.",
        epilog=(
            "Set VT_API_KEY in the environment. Missing hash/key are prompted for only "
            "on a terminal. Score = round(100*(malicious + 0.5*suspicious)/"
            "(malicious+suspicious+harmless)); undetected is excluded. "
            "Example: vt-indicator SHA256 -o indicators.json"
        ),
    )
    parser.add_argument("sha256", nargs="?", help="64 hexadecimal characters; prompted if omitted")
    parser.add_argument(
        "-o",
        "--output",
        default="-",
        metavar="PATH",
        help="JSON destination (default: - for stdout)",
    )
    return parser


def _prompt_hash() -> str:
    print("SHA256: ", end="", file=sys.stderr, flush=True)
    value = sys.stdin.readline()
    if value == "":
        raise EOFError
    return value.rstrip("\r\n")


def main(argv: Sequence[str] | None = None) -> int:
    """Run the CLI, returning 0 (success), 1 (failure), 2 (usage), or 130 (interrupt)."""
    parser = _parser()
    args = parser.parse_args(argv)
    try:
        sha256: str | None = args.sha256
        if sha256 is None:
            if not sys.stdin.isatty():
                print(
                    "vt-indicator: SHA256 is required without an interactive terminal.",
                    file=sys.stderr,
                )
                return 2
            sha256 = _prompt_hash()
        try:
            sha256 = validate_sha256(sha256)
        except ValueError as exc:
            print(f"vt-indicator: {exc}", file=sys.stderr)
            return 2

        api_key = os.environ.get("VT_API_KEY", "").strip()
        if not api_key:
            if not sys.stdin.isatty():
                print("vt-indicator: Set VT_API_KEY for non-interactive use.", file=sys.stderr)
                return 2
            # Refuse getpass's echoing fallback if a terminal cannot hide input.
            with warnings.catch_warnings():
                warnings.simplefilter("error", getpass.GetPassWarning)
                api_key = getpass.getpass("VirusTotal API key: ", stream=sys.stderr).strip()
            if not api_key:
                print("vt-indicator: An API key is required.", file=sys.stderr)
                return 2

        indicator = build_indicator(fetch_report(sha256, api_key), sha256)
        if args.output == "-":
            # Flush here so a closed pipe is handled before interpreter shutdown.
            print(json.dumps([indicator], indent=2, ensure_ascii=True, allow_nan=False), flush=True)
        else:
            write_json_atomic(Path(args.output), [indicator])
        return 0
    except (VirusTotalError, ReportError) as exc:
        print(f"vt-indicator: {exc}", file=sys.stderr)
        return 1
    except BrokenPipeError:
        # Avoid another BrokenPipeError when Python flushes stdout at shutdown.
        sys.stdout = open(os.devnull, "w")  # noqa: SIM115
        return 1
    except OSError:
        print(
            "vt-indicator: Could not write output; check the destination and permissions.",
            file=sys.stderr,
        )
        return 1
    except (EOFError, getpass.GetPassWarning):
        print(
            "vt-indicator: Input unavailable; provide SHA256 and VT_API_KEY explicitly.",
            file=sys.stderr,
        )
        return 2
    except KeyboardInterrupt:
        print("\nvt-indicator: Cancelled.", file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
