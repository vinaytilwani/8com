"""Small HTTP boundary: one lookup, bounded waits, no retries or output."""

import json
import re
from typing import cast

import requests

from vt_indicator.core import validate_sha256

API_URL = "https://www.virustotal.com/api/v3/files"
TIMEOUT = (5, 30)


class VirusTotalError(RuntimeError):
    """VirusTotal lookup failed; no indicator was produced."""


def _error_detail(response: requests.Response, api_key: str) -> str:
    """Expose only VT's documented error fields, with bounded, escaped text."""
    fallback = "No structured API error details were returned."
    try:
        payload: object = response.json()
    except ValueError:
        return fallback
    if not isinstance(payload, dict):
        return fallback
    error: object = payload.get("error")
    if not isinstance(error, dict):
        return fallback
    details: list[str] = []
    for field, limit in (("code", 80), ("message", 400)):
        value: object = error.get(field)
        if isinstance(value, str) and value:
            # Redact before truncating so a clipped credential cannot leak.
            value = re.sub(re.escape(api_key), "[REDACTED]", value, flags=re.IGNORECASE)
            if len(value) > limit:
                value = value[:limit] + "..."
            # JSON escaping keeps provider newlines/terminal controls inert.
            details.append(f"{field}={json.dumps(value, ensure_ascii=True)}")
    return "Provider error: " + "; ".join(details) if details else fallback


def fetch_report(sha256: str, api_key: str) -> dict[str, object]:
    """Retrieve an existing report; never upload or download the file itself.

    Raises ValueError for an invalid hash and VirusTotalError for lookup failures.
    Messages include only the provider's error code/message, redacting the supplied
    key and escaping control characters. Raw bodies, headers and low-level
    exceptions are excluded. The caller owns retry/scheduling policy.
    """
    sha256 = validate_sha256(sha256)
    api_key = api_key.strip()
    if not api_key:
        raise VirusTotalError("Pass a nonempty VirusTotal API key.")
    # Header encoding errors can escape Requests' exception hierarchy. Reject
    # invalid pasted characters before transmission, without echoing the key.
    if any(not 33 <= ord(character) <= 126 for character in api_key):
        raise VirusTotalError(
            "VirusTotal API key must contain visible ASCII characters, no spaces."
        )
    try:
        response = requests.get(
            f"{API_URL}/{sha256}",
            headers={"x-apikey": api_key},
            timeout=TIMEOUT,
            allow_redirects=False,
        )
    except requests.Timeout:
        raise VirusTotalError("VirusTotal request timed out; try again later.") from None
    except requests.RequestException:
        raise VirusTotalError("Could not connect to VirusTotal; check your connection.") from None

    try:
        status = response.status_code
        if status != 200:
            messages = {
                400: "VirusTotal rejected the request (HTTP 400).",
                401: "VirusTotal authentication failed (HTTP 401).",
                403: "VirusTotal denied access; check API permissions (HTTP 403).",
                404: "VirusTotal has no report for this hash (HTTP 404); safety is unknown.",
                429: "VirusTotal quota or rate limit reached (HTTP 429); try again later.",
            }
            raise VirusTotalError(
                messages.get(status, f"VirusTotal request failed (HTTP {status}).")
                + " "
                + _error_detail(response, api_key)
            )
        try:
            payload: object = response.json()
        except ValueError:
            raise VirusTotalError("VirusTotal returned invalid JSON.") from None
        if not isinstance(payload, dict) or any(not isinstance(key, str) for key in payload):
            raise VirusTotalError("VirusTotal response must be a JSON object.")
        return cast("dict[str, object]", payload)
    finally:
        response.close()
