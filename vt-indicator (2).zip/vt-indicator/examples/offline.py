"""Run the pure transformation on synthetic data, without a key or network."""

import json
from pathlib import Path

from vt_indicator import build_indicator


def main() -> None:
    fixture = Path(__file__).with_name("vt_response.synthetic.json")
    report: object = json.loads(fixture.read_text(encoding="utf-8"))
    indicator = build_indicator(report, "ab" * 32)
    print(json.dumps([indicator], indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
