# How to understand and explain vt-indicator

## What the program contributes

An alert provides a SHA256 hash. VirusTotal may already hold an analysis report
for that exact file. Our program retrieves the report and converts it into a
small, predictable indicator that a person, a shell pipeline, or a SOAR playbook
can use.

The program is an enrichment component. It does not execute malware, perform a
new scan, or decide whether to quarantine a machine. Its job is to preserve the
relevant evidence and make our interpretation explicit.

The core design decision is to separate interpretation from input/output.
That makes the logic easy to test and lets another application use it without
starting a command-line process.

## Read the code in this order

| File/function | What to look for |
|---|---|
| `core.py: calculate_score` | The mathematical contract and its edge cases. |
| `core.py: build_indicator` | How provider fields become the output schema. |
| `client.py: fetch_report` | HTTP request, credentials, timeout, and errors. |
| `cli.py: main` | How the command orchestrates those functions. |
| `cli.py: write_json_atomic` | How existing output is protected from partial writes. |
| `tests/test_indicator.py` | Concrete examples and generated invariants. |

Function names are a navigation aid; there is no generic helpers module that
collects unrelated responsibilities.

## The scoring decision

We assign a malicious verdict weight 1, a suspicious verdict weight 0.5, and a
harmless verdict weight 0. Every explicit verdict contributes one to the denominator:

```text
score = round(100 * (malicious + 0.5*suspicious)
                  / (malicious + suspicious + harmless))
```

For six malicious, two suspicious, and two harmless verdicts, the weighted sum
is seven and the denominator is ten: the score is **70**. Undetected results do
not affect it, following our chosen interpretation of abstaining engines.

This is a weighted index of explicit verdicts. It is not a probability that a
file is malware. One malicious verdict and 69 undetected results score 100;
the output includes counts so consumers can see that the evidence base is only
one explicit verdict. A null score means there were no usable explicit verdicts
or the analysis statistics were absent. Zero requires actual harmless evidence.

Two details are worth explaining in an interview:

- Adding suspicious verdicts moves the score toward 50. It can lower a score
  above 50 because we chose suspicious evidence to have half weight.
- `Fraction` computes the ratio exactly. Python's ties-to-even rounding makes
  12.5 become 12 and 37.5 become 38. The rounding rule is tested and documented.

The 0.5 weight is a transparent project policy, not an empirically calibrated
constant. The versioned method string makes that policy identifiable downstream.

Community reputation is copied separately because its origin and weighting
differ from engine verdicts. Combining the two would introduce another policy
that this assignment does not need.

## Pure functions and validation

`build_indicator(report, expected_sha256)` depends only on its arguments. It does
not read an API key, contact a server, consult the current time, or change the
report. The same input therefore gives the same output.

It checks that the returned object is a file and has the expected SHA256. It then
validates the fields it uses. Absent optional evidence becomes null, while
present malformed evidence raises `ReportError`. For example, the string `"6"`
is not silently converted to six engines, and a missing harmless category is
not silently interpreted as zero. Unknown, unrelated attributes are ignored.

Python treats `bool` as a subclass of `int`. Without an explicit check, `True`
could accidentally become one engine. The integer validator rejects booleans.

Timestamps are converted from Unix seconds into UTC ISO 8601 strings. `first_seen`
means first submission to VirusTotal; it does not claim to identify when the
file was created or first used in an attack.

## Why use TypedDict?

`Indicator`, `Community`, `Votes`, and `Evidence` describe the exact dictionary
shapes expected by callers. This gives editor assistance and static checking,
while allowing direct serialization with `json.dumps`.

TypedDict is a static contract, not a runtime parser. The explicit field checks
protect the boundary where untrusted JSON enters the program. Mypy verifies our
use of the resulting types. Neither replaces the other.

The incoming report starts as `object`: its structure is not trusted yet.
Only after checking an object is a dictionary with string keys do we narrow its
type. This avoids spreading unvalidated `Any` values through the program.

## Credentials belong at the outer boundary

The CLI reads `VT_API_KEY` or asks for a key using `getpass` in an interactive
terminal. The Python API accepts the key explicitly:

```python
report = fetch_report(sha256, api_key)
indicator = build_indicator(report, sha256)
```

A SOAR platform can retrieve `api_key` from its own secret store. It can also
use its existing VirusTotal connector and call only `build_indicator`. The
library never prompts or reads the environment on the caller's behalf.

The HTTP request sends the key in `x-apikey`, uses HTTPS and connection/read
timeouts, and refuses redirects. Invalid pasted key characters are rejected
before the HTTP library tries to encode them. Error messages retain the provider's
documented error code and message to make failures diagnosable. They redact the
supplied key, bound the text, and escape control characters; raw response bodies,
headers, and low-level network exception text are omitted.

There is one lookup attempt. Rate-limit and other HTTP errors are reported to
the caller; scheduling, retry, and backoff policies can be supplied by SOAR later.

## Unix behaviour and Windows use

The command's stdout is a data channel: it contains only the JSON array. Errors
and prompts use stderr. This allows `jq` or PowerShell's `ConvertFrom-Json` to
consume the result reliably.

Exit status describes execution, not threat severity. Successfully returning a
score of 100 still exits with zero. A failed lookup exits with one. Missing or
invalid CLI inputs exit with two. A script should check status before consuming
an output file, since a failed run intentionally leaves an old file intact.

The CLI flushes stdout while still inside its exception handler. A reviewer
found that otherwise a small JSON result could remain buffered and fail later
at interpreter shutdown if the downstream consumer closed its pipe.

For files, we first write the complete document to a temporary file in the
destination directory, then atomically replace the destination. Readers see
either the old document or the new one, rather than half-written JSON. This
does not promise that data survives sudden power loss.

## What the tests demonstrate

An independent agent wrote the initial tests against the interface contract.
Three further reviewers checked implementation, test quality, and documentation.

| Test style | Why it is useful |
|---|---|
| Hand-calculated examples | Catch using the wrong weight, denominator, or rounding. |
| Hypothesis properties | Check many generated count combinations for invariants. |
| Malformed report cases | Check that missing data and invalid data are treated deliberately. |
| Fake HTTP responses | Exercise failures without using credentials or consuming quota. |
| Subprocess checks | Exercise installed entry points and real process/pipe behaviour. |
| Temporary-directory tests | Verify file contents, atomic replacement, and cleanup. |
| Golden example comparison | Keep the documented synthetic output consistent with the transformation. |

Properties include bounds, scale invariance, excluded-category invariance,
monotonicity for malicious/harmless counts, and movement toward 50 when adding
suspicious verdicts. A test must reflect the chosen weighted formula: asserting
that adding suspicious verdicts always raises the score would be incorrect.

Mocks have limits. Mocking `getpass` proves delegation and non-serialization,
not actual terminal echo control. A separate Linux pseudo-terminal check verified
echo suppression and restoration. That does not establish Windows behaviour.
Similarly, fake API responses cannot establish that a real key is authorized.

Review found and addressed malformed-key exceptions, a long-filename temporary
file problem, and subprocess timeouts that originally did not cover blocking
reads. These are recorded in `VERIFICATION.md`; tests and coverage remain evidence
of checked behaviour, not a proof that every possible input is handled.

## A concise explanation you can give

“I separated the provider client, pure transformation, and command-line adapter.
The core produces a typed, JSON-serializable indicator and preserves the counts
behind its score. The score is a documented weighted index, with null for absent
evidence; community reputation remains separate. Both command-line users and a
SOAR playbook call the same logic. I verified the mathematical properties and
failure paths offline, checked actual process and pipe behaviour, and kept a
real malware hash as a separate optional live lookup example.”
