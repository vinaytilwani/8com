# vt-indicator

Look up a file's SHA256 in VirusTotal and save the result as a JSON indicator.
Use it interactively, from the command line, or as part of a SOAR playbook.

## Setup

Requires Python 3.12+ and [uv](https://docs.astral.sh/uv/getting-started/installation/).
For Windows installation and PowerShell examples, see [WINDOWS.md](WINDOWS.md).

```sh
uv sync --locked
```

## Usage

Run interactively:

```sh
uv run vt-indicator -o indicators.json
```

Enter the SHA256 and your VirusTotal API key when prompted. The key is hidden
and is not saved. If `VT_API_KEY` is set in the environment, the program uses it
instead of prompting.

Or supply the hash directly, replacing `YOUR_SHA256` with the actual hash:

```sh
uv run vt-indicator YOUR_SHA256 -o indicators.json
```

Without `-o`, JSON goes to stdout, so it can be piped into other tools:

```sh
uv run vt-indicator YOUR_SHA256 | jq '.[0].score'
```

For automated jobs, supply both the hash and `VT_API_KEY`; prompts are only
available in an interactive terminal. Use `--help` to see the options.

After setup, try the synthetic example without a key or network request:

```sh
uv run --no-sync python examples/offline.py
```

A real MalwareBazaar example hash and its source are in
[examples/malwarebazaar.json](examples/malwarebazaar.json).

## Score

The score gives malicious verdicts full weight and suspicious verdicts half weight:

```text
score = round(100 * (malicious + 0.5 * suspicious)
                 / (malicious + suspicious + harmless))
```

Undetected results, failures, and timeouts are excluded. If there are no explicit
verdicts or the statistics are unavailable, the score is `null`.
This summarizes engine verdicts; it is not a probability that the file is malicious.
Community reputation is included separately.

## Output and errors

The output is a JSON array containing one indicator: the hash, score, engine
counts, filename, timestamps, community reputation, and original engine statistics.
See [examples/indicator.synthetic.json](examples/indicator.synthetic.json).

`first_seen` means the first submission to VirusTotal. Missing optional information
is represented as `null`.

Errors go to stderr. Exit codes are `0` for success, `1` for operational failures,
`2` for invalid or missing input, and `130` for Ctrl+C. A failed lookup leaves an
existing output file untouched. A successful run replaces it.

The tool retrieves existing reports. It does not upload files or retry failed requests.

## Python / SOAR

Pass the API key from your platform's secret store:

```python
from vt_indicator import build_indicator, fetch_report

report = fetch_report(sha256, api_key)
indicator = build_indicator(report, sha256)
```

These functions do not prompt or print. If your SOAR connector already provides
the report, call `build_indicator` directly.

## Development

```sh
uv run pytest
uv run ruff check .
uv run ruff format --check .
uv run mypy
```

Tests run without a VirusTotal key and include property-based checks with Hypothesis.

See [EXPLAINER.md](EXPLAINER.md) for the design and code walkthrough, and
[VERIFICATION.md](VERIFICATION.md) for verification results and limitations.
